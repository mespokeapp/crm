﻿using MeSpoke.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace MeSpoke.AdminUI.Controllers {
    [Authorize]
    public class PostReportController : Controller {

        private readonly PostService service;

        public PostReportController(PostService srv) {
            service = srv;
        }

        public ActionResult Index() {
            ViewBag.Url = "/PostReport/DataJson";
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Remove(Guid id) {
            await service.DeletePostAsync(id);
            return RedirectToAction("Index");
        }

        public async Task<JsonResult> DataJson() {
            return Json(await service.GetPostReport(), JsonRequestBehavior.AllowGet);
        }
    }
}
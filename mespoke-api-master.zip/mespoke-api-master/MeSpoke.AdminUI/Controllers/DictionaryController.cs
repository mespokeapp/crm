﻿using MeSpoke.Models;
using MeSpoke.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace MeSpoke.AdminUI.Controllers {
    [Authorize]
    public class DictionaryController : Controller {

        private readonly DictionaryService service;

        public DictionaryController(DictionaryService srv) {
            service = srv;
        }

        public ActionResult Brands() {
            ViewBag.Url = "/Dictionary/BrandsJson";
            return View("Index");
        }

        public ActionResult Categories() {
            ViewBag.Url = "/Dictionary/CategoriesJson";
            return View("Index");
        }

        public ActionResult Retailers() {
            ViewBag.Url = "/Dictionary/RetailersJson";
            return View("Index");
        }

        public async Task<JsonResult> BrandsJson() {
            return Json(await service.GetAllBrandsOrderedByNameAsync(), JsonRequestBehavior.AllowGet);
        }

        public async Task<JsonResult> CategoriesJson() {
            return Json(await service.GetAllCategoriesOrderedByNameAsync(), JsonRequestBehavior.AllowGet);
        }

        public async Task<JsonResult> RetailersJson() {
            return Json(await service.GetAllRetailersOrderedByNameAsync(), JsonRequestBehavior.AllowGet);
        }

        public async Task<ActionResult> Create() {
            return View("Edit", await service.CreateAsync());
        }

        [HttpPost]
        public async Task<ActionResult> Create(Dictionary data) {
            if (!ModelState.IsValid)
                return View("Edit", data);

            await service.AddAsync(data);
            return RedirectToAction("Brands");
        }

        public async Task<ActionResult> Edit(Guid id) {
            var brand = await service.FindAsync(id);
            if (brand == null)
                return HttpNotFound();

            return View(brand);
        }

        [HttpPost]
        [ActionName("Edit")]
        public async Task<ActionResult> EditPost(Guid id) {
            var brand = await service.FindAsync(id);
            if (brand == null)
                return HttpNotFound();

            if (TryUpdateModel(brand, new string[] { "Id", "Name", "Type", "URL" })) {
                await service.EditAsync(brand);
                return RedirectToAction("Brands");
            }

            return View(brand);
        }

        public async Task<ActionResult> Hide(Guid id) {
            var brand = await service.FindAsync(id);
            if (brand == null)
                return HttpNotFound();

            return View(brand);
        }

        [HttpPost]
        [ActionName("Hide")]
        public async Task<ActionResult> HidePost(Guid id) {
            var brand = await service.FindAsync(id);
            if (brand == null)
                return HttpNotFound();

            if (brand.EndDate == null)
                await service.HideAsync(brand);
            else
                await service.UnhideAsync(brand);

            return RedirectToAction("Brands");
        }
    }
}

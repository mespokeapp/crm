﻿using MeSpoke.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace MeSpoke.AdminUI.Controllers {
    [Authorize]
    public class DashboardController : Controller {
        private readonly DashboardService service;

        public DashboardController(DashboardService srv) {
            service = srv;
        }

        public ActionResult Index() {
            return View();
        }

        public async Task<JsonResult> SpeakersJson() {
            var data = await service.SpeakersJson();
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public async Task<JsonResult> SignupsJson() {
            var data = await service.SignupsJson();
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public async Task<JsonResult> PostUploadsJson() {
            var data = await service.PostUploadsJson();
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public async Task<JsonResult> ActiveUsersJson() {
            var data = await service.ActiiveUsersJson();
            return Json(data, JsonRequestBehavior.AllowGet);
        }
    }
}
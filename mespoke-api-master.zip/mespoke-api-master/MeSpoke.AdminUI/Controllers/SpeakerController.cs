﻿using MeSpoke.Services;
using MeSpoke.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace MeSpoke.AdminUI.Controllers {
    [Authorize]
    public class SpeakerController : Controller {
        private readonly SpeakerService service;

        public SpeakerController(SpeakerService srv) {
            service = srv;
        }

        public ActionResult Index() {
            return View();
        }

        public async Task<JsonResult> ListJson() {
            return Json(await service.ListSpeakersAsync(), JsonRequestBehavior.AllowGet);
        }

        public async Task<JsonResult> ListUsersWithoutProfilesJson() {
            return Json(await service.ListUsersWithoutProfilesAsync(), JsonRequestBehavior.AllowGet);
        }

        public async Task<ActionResult> Suspend(string userid, bool userblocked) {
            await service.SwitchSpeakerBlockStatusAsync(userid, userblocked);
            return RedirectToAction("Index");
        }

        public async Task<ActionResult> Delete(string userid) {
            await service.DeleteSpeakerAsync(userid);
            return RedirectToAction("Index");
        }
    }
}
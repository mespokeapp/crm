﻿var app = angular.module('DictionaryApp', []);
app.service('dictionaryService', ['$http', function ($http) {
    this.getList = function (url, $scope) {
        return $http.get(url).then(
            function (data) {
                $scope.list = data.data;
                $scope.error = null;
            }, function (error) {
                $scope.list = null;
                $scope.error = error.statusText;
            });
    }
}]);
app.filter('moment', function () {
    return function (dateString, format) {
        return moment(dateString).format(format);
    };
});
app.filter('startFrom', function () {
    return function (input, start) {
        if (!input)
            return;
        start = +start; //parse to int
        return input.slice(start);
    }
});
app.controller('DictionaryController', ['$scope', '$filter', 'dictionaryService', function ($scope, $filter, dictionaryService) {
    $scope.currentPage = 0;
    $scope.pageSize = 14;
    $scope.getData = function () {
        var data = [];
        if ($scope.searchCheck)
            data = $filter('filter')($scope.list, { 'Name': $scope.searchList, 'EndDate': null });
        else
            data = $filter('filter')($scope.list, { 'Name': $scope.searchList });
        return data;
    }
    $scope.numberOfPages = function () {
        return Math.ceil($scope.getData().length / $scope.pageSize);
    }
    $scope.prev = function () {
        $scope.currentPage = $scope.currentPage - 1
    }
    $scope.prevDisabled = function () {
        return $scope.currentPage == 0
    }
    $scope.next = function () {
        $scope.currentPage = $scope.currentPage + 1
    }
    $scope.nextDisabled = function () {
        return $scope.currentPage >= $scope.getData().length / $scope.pageSize - 1
    }

    $scope.list = [];
    $scope.searchList = '';
    $scope.searchCheck = false;
    $scope.error = null;
    $scope.active = 1;

    $scope.initialize = function (url) {
        dictionaryService.getList(url, $scope)
    };

    $scope.orderByColumn = function (x) {
        $scope.orderBy = x;
    }
}]);


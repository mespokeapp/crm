//
//  Chart #1
// 
google.load("visualization", "1", {
    packages: ["corechart"]
});
google.setOnLoadCallback(drawChart1);

function drawChart1() {

    $.ajax({
        url: "/Dashboard/SpeakersJson",
        dataType: "json",
    }).done(function (json) {
        var barData = new google.visualization.DataTable(json);

        // set bar chart options
        var barOptions = {
            focusTarget: 'category',
            backgroundColor: '#fff',
            colors: ['#000'],
            fontName: 'Raleway',
            chartArea: {
                left: 50,
                top: 40,
                right: 50,
                width: '90%',
                height: '75%'
            },
            annotations: {
                position: 'bottom'
            },
            bar: {
                groupWidth: '100%'
            },
            hAxis: {
                textStyle: {
                    fontSize: 14,
                    color: '#9a9a9a'
                }
            },
            vAxis: {
                minValue: 0,
                maxValue: 40,
                baselineColor: '#000',
                gridlines: {
                    color: '#e2ecf5',
                    count: 6
                },
                textStyle: {
                    fontSize: 14,
                    color: '#9a9a9a'
                }
            },
            legend: {
                position: 'none',
                textStyle: {
                    fontSize: 12
                }
            },
            animation: {
                duration: 1200,
                easing: 'out',
                startup: true
            }
        };
        // draw bar chart twice so it animates
        var barChart = new google.visualization.ColumnChart(document.getElementById('bar-chart'));
        barChart.draw(barData, barOptions);
    });
}

//
//  Chart #2
// 
google.load("visualization", "1", {
    packages: ["corechart"]
});
google.setOnLoadCallback(drawChart2);

function drawChart2() {
    $.ajax({
        url: "/Dashboard/SignupsJson",
        dataType: "json",
    }).done(function (json) {
        // actual bar chart data
        var barData = new google.visualization.DataTable(json);

        // set bar chart options
        var barOptions = {
            focusTarget: 'category',
            backgroundColor: '#fff',
            colors: ['#000'],
            fontName: 'Raleway',
            chartArea: {
                left: 50,
                top: 40,
                right: 50,
                width: '90%',
                height: '75%'
            },
            bar: {
                groupWidth: '100%'
            },
            hAxis: {
                textStyle: {
                    fontSize: 14,
                    color: '#9a9a9a'
                }
            },
            vAxis: {
                minValue: 0,
                maxValue: 5,
                baselineColor: '#000',
                gridlines: {
                    color: '#e2ecf5',
                    count: 5
                },
                textStyle: {
                    fontSize: 14,
                    color: '#9a9a9a'
                }
            },
            legend: {
                position: 'none',
                textStyle: {
                    fontSize: 12
                }
            },
            animation: {
                duration: 1200,
                easing: 'out',
                startup: true
            }
        };
        // draw bar chart twice so it animates
        var barChart = new google.visualization.ColumnChart(document.getElementById('bar-chart-2'));
        barChart.draw(barData, barOptions);
    })
}


//
//  Chart #3
// 
google.load("visualization", "1", {
    packages: ["corechart"]
});
google.setOnLoadCallback(drawChart3);

function drawChart3() {
    $.ajax({
        url: "/Dashboard/ActiveUsersJson",
        dataType: "json",
    }).done(function (json) {
        // actual bar chart data
        var barData = new google.visualization.DataTable(json);

        // set bar chart options
        var barOptions = {
            focusTarget: 'category',
            backgroundColor: '#fff',
            colors: ['#000'],
            fontName: 'Raleway',
            chartArea: {
                left: 50,
                top: 40,
                right: 50,
                width: '90%',
                height: '75%'
            },
            bar: {
                groupWidth: '100%'
            },
            hAxis: {
                textStyle: {
                    fontSize: 14,
                    color: '#9a9a9a'
                }
            },
            vAxis: {
                minValue: 0,
                maxValue: 5,
                baselineColor: '#000',
                gridlines: {
                    color: '#e2ecf5',
                    count: 5
                },
                textStyle: {
                    fontSize: 14,
                    color: '#9a9a9a'
                }
            },
            legend: {
                position: 'none',
                textStyle: {
                    fontSize: 12
                }
            },
            animation: {
                duration: 1200,
                easing: 'out',
                startup: true
            }
        };
        // draw bar chart twice so it animates
        var barChart = new google.visualization.ColumnChart(document.getElementById('bar-chart-3'));
        barChart.draw(barData, barOptions);
    })
}
//
//  Chart #4
//
google.load("visualization", "1", {
    packages: ["corechart"]
});
google.setOnLoadCallback(drawChart4);

function drawChart4() {
    $.ajax({
        url: "/Dashboard/PostUploadsJson",
        dataType: "json",
    }).done(function (json) {
        // actual bar chart data
        var barData = new google.visualization.DataTable(json);
        // set bar chart options
        var barOptions = {
            focusTarget: 'category',
            backgroundColor: '#fff',
            colors: ['#000'],
            fontName: 'Raleway',
            chartArea: {
                left: 50,
                top: 40,
                right: 50,
                width: '90%',
                height: '75%'
            },
            annotations: {
                position: 'bottom'
            },
            bar: {
                groupWidth: '100%'
            },
            hAxis: {
                textStyle: {
                    fontSize: 14,
                    color: '#9a9a9a'
                }
            },
            vAxis: {
                minValue: 0,
                maxValue: 60,
                baselineColor: '#000',
                gridlines: {
                    color: '#e2ecf5',
                    count: 6
                },
                textStyle: {
                    fontSize: 14,
                    color: '#9a9a9a'
                }
            },
            legend: {
                position: 'none',
                textStyle: {
                    fontSize: 12
                }
            },
            animation: {
                duration: 1200,
                easing: 'out',
                startup: true
            }
        };
        // draw bar chart twice so it animates
        var barChart = new google.visualization.ColumnChart(document.getElementById('bar-chart-4'));
        barChart.draw(barData, barOptions);
    })
}
//
//  Resizing Charts
//
$(window).resize(function () {
    drawChart1();
    drawChart2();
    drawChart3();
    drawChart4();
});

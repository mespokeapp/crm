﻿var app = angular.module('SpeakerApp', []);
app.service('speakerService', ['$http', function ($http) {
    this.getList = function (url, $scope) {
        return $http.get(url).then(
            function (data) {
                $scope.list = data.data;
                $scope.error = null;
            }, function (error) {
                $scope.list = null;
                $scope.error = error.statusText;
            });
    }
}]);
app.filter('moment', function () {
    return function (timeSpan) {
        return moment.duration(timeSpan).humanize(true);
    };
});
app.filter('startFrom', function () {
    return function (input, start) {
        if (!input)
            return;
        start = +start; //parse to int
        return input.slice(start);
    }
});
app.controller('SpeakerController', ['$scope', '$filter', 'speakerService', function ($scope, $filter, speakerService) {
    $scope.currentPage = 0;
    $scope.pageSize = 11;
    $scope.getData = function () {
        // needed for the pagination calc
        // https://docs.angularjs.org/api/ng/filter/filter
        return $filter('filter')($scope.list, $scope.searchList)
    }
    $scope.numberOfPages = function () {
        return Math.ceil($scope.getData().length / $scope.pageSize);
    }
    $scope.prev = function () {
        $scope.currentPage = $scope.currentPage - 1
    }
    $scope.prevDisabled = function () {
        return $scope.currentPage == 0
    }
    $scope.next = function () {
        $scope.currentPage = $scope.currentPage + 1
    }
    $scope.nextDisabled = function () {
        return $scope.currentPage >= $scope.getData().length / $scope.pageSize - 1
    }

    $scope.list = [];
    $scope.error = null;
    $scope.active = 1;

    $scope.orderByColumn = function (x) {
        $scope.orderBy = x;
    }

    speakerService.getList('/Speaker/ListJson', $scope);
}]);

